package com.android.electronicdisplay;

import com.example.electronicdisplay.R;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

public class GuideActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_guide);
		
		ViewPager pager = (ViewPager) findViewById(R.id.view_pager);
		ImageAdapter imageAdapter = new ImageAdapter(this);
		pager.setAdapter(imageAdapter);
	}
}

class ImageAdapter extends PagerAdapter
{
	private Context context;
	
	private int bgArray[] = {
    		R.drawable.christmas01,
    		R.drawable.christmas04,
    		R.drawable.christmas06,
    		R.drawable.christmas07
		};
	
	ImageAdapter(Context context)
	{
		this.context = context;
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return bgArray.length;
	}

	@Override
	public boolean isViewFromObject(View view, Object object) {
		// TODO Auto-generated method stub
		return view == ((ImageView) object);
	}
	
	@Override
	public Object instantiateItem(ViewGroup container, int position) {

		ImageView img = new ImageView(context);
		img.setImageResource(bgArray[position]);
		
		((ViewPager) container).addView(img, 0);
		
		return img;
	}
	
	@Override
	public void destroyItem(ViewGroup container, int position, Object object) {
		((ViewPager) container).removeView((ImageView) object);
	}
}
