package com.android.electronicdisplay;

import com.example.electronicdisplay.R;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.os.Build;

public class MainActivity extends Activity {
	private EditText prefEditText;
	private SharedPreferences pref;
	private SharedPreferences.Editor editor;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		prefEditText = (EditText) findViewById(R.id.preference_edit);
		pref = getSharedPreferences("com.android.eletronicdisplay", MODE_PRIVATE);
	}

	public void clickHandler(View target)
	{
		switch(target.getId())
		{
		case R.id.preference_confirm:
			
			boolean viewCheck = pref.getBoolean("GuideActivity", true);
			prefEditText.setText("View Check : " + viewCheck);
			
			break;
			
		case R.id.preference_remove:
			editor = pref.edit();
			editor.clear();
			editor.commit();
			prefEditText.setText("Preferences Remove (default : " + pref.getBoolean("GuideActivity", true)+ ")");
			break;
			
		}
	}

}
